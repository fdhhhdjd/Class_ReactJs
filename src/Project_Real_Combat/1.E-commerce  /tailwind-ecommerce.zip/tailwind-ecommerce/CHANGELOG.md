# Release Notes for 2.x

<a name="2.0.0"></a>
# [2.0.0](https://github.com/bbulakh/tailwind-ecommerce) (2023-06-17)
- Migrate from Gulp to Parcel;
- Make social media icons clickable;


