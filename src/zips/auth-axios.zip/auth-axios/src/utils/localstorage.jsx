export function getToken(key) {
  return localStorage.getItem(key);
}

export function setToken(key, value) {
  return localStorage.setItem(key, value);
}

export function clearToken(key) {
  return localStorage.removeItem(key);
}

export function getLocalStorage(key) {
  const value = localStorage.getItem(key);

  return JSON.parse(value);
}

export function setLocalStorage(key, value) {
  return localStorage.setItem(key, value);
}
