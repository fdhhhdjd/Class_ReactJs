import { useEffect } from "react";
import "./App.css";
import { axiosIns } from "../libs/axios";
import { setToken } from "./utils/localstorage";

function App() {
  const handleLogin = () => {
    setToken("auth", "àbisdfipoaqjfkosdfnmpalksjfksldfmpsdalkfmlpwdeasfkwedl");
  };

  useEffect(() => {
    const handleCheckAuth = () => {
      return axiosIns
        .get("/user1")
        .then((response) => {
          console.log(response.data);
          return response.data;
        })
        .catch((error) => {
          throw error;
        });
    };

    handleCheckAuth();
  }, []);

  return (
    <>
      <h1>Hello</h1>
      <button onClick={handleLogin}>Login</button>
    </>
  );
}

export default App;
