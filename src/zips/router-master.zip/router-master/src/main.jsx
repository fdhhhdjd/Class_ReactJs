//* LIB
import ReactDOM from "react-dom/client";
import { BrowserRouter as Router } from "react-router-dom";

//* APP
import App from "./App.jsx";

//* CSS
import "./index.css";

//* GLOBAL
import { AuthProvider } from "./contexts/index.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <Router>
    <AuthProvider>
      <App />
    </AuthProvider>
  </Router>
);
