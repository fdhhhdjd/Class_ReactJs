//* LIB
import { useContext } from "react";

//* STORE
import { authContext } from "@/contexts";

export default function useAuth() {
  return useContext(authContext);
}
