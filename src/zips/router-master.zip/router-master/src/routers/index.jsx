//* LIB
import { useRoutes } from "react-router-dom";

//* LAYOUT
import Navbar from "@/layouts/Navbar";

//* IMPORT PAGE
import {
  AboutDetailPage,
  AboutPage,
  ContactPage,
  HomePage,
  LoginPage,
  NotFoundPage,
} from "@/imports/pages";

//* ROUTERS
import OutLetChild from "./OutLetChild";
import useAuth from "@/hooks/useAuth";

const RoutesPage = () => {
  const { theme } = useAuth();

  let elements = useRoutes([
    {
      path: "/",
      element: <OutLetChild>{/* <Navbar /> */}</OutLetChild>,
      children: [
        {
          index: true,
          element: (
            <div className={theme ? "AppTheme" : "App"}>
              <HomePage />
            </div>
          ),
        },
        {
          path: "about",
          element: (
            <div className={theme ? "AppTheme" : "App"}>
              <OutLetChild>
                <AboutPage />
              </OutLetChild>
            </div>
          ),
          children: [
            {
              path: ":id",
              element: <AboutDetailPage />,
            },
          ],
        },
        {
          path: "contact",
          element: <ContactPage />,
        },
        {
          path: "login",
          element: <LoginPage />,
        },
      ],
    },

    {
      path: "*",
      element: <NotFoundPage />,
    },
  ]);
  return elements;
};

export default RoutesPage;
