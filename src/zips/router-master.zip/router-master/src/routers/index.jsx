//* LIB
import { useRoutes } from "react-router-dom";

//* LAYOUT
import Navbar from "@/layouts/Navbar";

//* IMPORT PAGE
import {
  AboutDetailPage,
  AboutPage,
  ContactPage,
  HomePage,
  LoginPage,
  NotFoundPage,
} from "@/imports/pages";

//* ROUTERS
import OutLetChild from "./OutLetChild";

const RoutesPage = () => {
  let elements = useRoutes([
    {
      path: "/",
      element: (
        <OutLetChild>
          <Navbar />
        </OutLetChild>
      ),
      children: [
        {
          index: true,
          element: <HomePage />,
        },
        {
          path: "about",
          element: (
            <OutLetChild>
              <AboutPage />
            </OutLetChild>
          ),
          children: [
            {
              path: ":id",
              element: <AboutDetailPage />,
            },
          ],
        },
        {
          path: "contact",
          element: <ContactPage />,
        },
        {
          path: "login",
          element: <LoginPage />,
        },
      ],
    },

    {
      path: "*",
      element: <NotFoundPage />,
    },
  ]);
  return elements;
};

export default RoutesPage;
