//*  LIB
import { createContext, useReducer, useState } from "react";

//* UTILS
import {
  ClearAllLocalStorage,
  GetLocalStorage,
  SetLocalStorage,
} from "@/utils/Localstorage";

const initialState = {
  count: 0,
};

export const authContext = createContext();

export const incrementAction = () => {
  return {
    type: "increment",
  };
};

export const decrementAction = () => {
  return {
    type: "decrement",
  };
};

export function countReducer(state, action) {
  switch (action.type) {
    case "increment":
      return {
        ...state,
        count: +state.count + 1,
      };
    case "decrement":
      return {
        ...state,
        count: +state.count - 1,
      };

    default:
      throw new Error();
  }
}

export const AuthProvider = ({ children }) => {
  const [state, dispatch] = useReducer(countReducer, initialState);

  const [user, setUser] = useState(false);
  const [theme, setTheme] = useState(false);

  const handleChangeTheme = () => {
    setTheme(!theme);
  };

  const handleSetLocalStorage = () => {
    SetLocalStorage("tai");
    return alert("Set Data Oke");
  };

  const handleGetLocalStorage = () => {
    const dataNew = GetLocalStorage("tai");
    return alert(JSON.stringify(dataNew));
  };
  const handleDeleteLocalStorage = () => {
    ClearAllLocalStorage();
    return alert("Clear Data Oke");
  };

  const data = {
    user,
    setUser,
    theme,
    setTheme,
    handleChangeTheme,
    handleSetLocalStorage,
    handleGetLocalStorage,
    handleDeleteLocalStorage,
    state,
    dispatch,
  };

  authContext.displayName = "AuthContext";

  return <authContext.Provider value={data}>{children}</authContext.Provider>;
};
