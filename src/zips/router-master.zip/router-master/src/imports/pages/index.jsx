//* PAGE
export { default as HomePage } from "@/pages/home";
export { default as AboutPage } from "@/pages/about";
export { default as ContactPage } from "@/pages/contact";
export { default as NotFoundPage } from "@/pages/notfound";

//* PAGE CHILD
export { default as AboutDetailPage } from "@/pages/about/detail";

//* PAGE AUTH
export { default as LoginPage } from "@/pages/auth/login";
