const Contacts = () => {
  return (
    <>
      <h1>Contacts</h1>
    </>
  );
};

export default Contacts;
