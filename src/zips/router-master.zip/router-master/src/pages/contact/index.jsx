import useAuth from "@/hooks/useAuth";

const Contacts = () => {
  const data = useAuth();
  return (
    <>
      <h1>Contacts</h1>
    </>
  );
};

export default Contacts;
