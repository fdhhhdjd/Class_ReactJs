import { addTodoAction, deleteTodoAction } from "@/stores/action";
import todoReducer, { initState } from "@/stores/reducer";
import { useReducer, useState } from "react";

const Home = () => {
  const [form, setForm] = useState({
    todo: "",
  });

  // used useReducer
  const [state, dispatch] = useReducer(todoReducer, initState);

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleAddTodo = (e) => {
    e.preventDefault();

    dispatch(addTodoAction(form));
    handleClearInput();
  };

  const handleDeleteTodo = (id) => {
    dispatch(deleteTodoAction(id));
  };

  const handleClearInput = () => {
    setForm({
      todo: "",
    });
  };

  return (
    <>
      <form onSubmit={handleAddTodo}>
        <label htmlFor="todo" style={{ marginRight: "1rem" }}>
          Todo
        </label>
        <input
          id="todo"
          type="text"
          name="todo"
          value={form.todo}
          onChange={handleChange}
          placeholder="Please enter input"
        />
        <button onClick={handleAddTodo}>Add</button>
      </form>

      {state?.todos.map((item) => {
        return (
          <ul key={item.id}>
            <li>{item.text}</li>
            <button onClick={() => handleDeleteTodo(item.id)}>X</button>
          </ul>
        );
      })}
    </>
  );
};

export default Home;
