import { decrementAction, incrementAction } from "@/contexts";
import useAuth from "@/hooks/useAuth";

const About = () => {
  const { state, dispatch } = useAuth();
  return (
    <>
      <h1>About</h1>
      <h1>{state.count}</h1>
      <button onClick={() => dispatch(incrementAction())}>+</button>
      <button onClick={() => dispatch(decrementAction())}>-</button>
    </>
  );
};

export default About;
