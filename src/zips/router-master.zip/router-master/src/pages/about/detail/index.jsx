const AboutDetail = () => {
  return <h1>AboutDetail</h1>;
};

export default AboutDetail;
