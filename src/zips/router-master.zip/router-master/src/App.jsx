//* LIB
import { Suspense } from "react";

//* ROUTERS
import RoutesPage from "./routers";

//* COMPONENTS
import Loading from "./components/Loading";

//* STYLES
import "@/styles/App.css";

function App() {
  return (
    <>
      <Suspense fallback={<Loading />}>
        <RoutesPage />
      </Suspense>
    </>
  );
}

export default App;
