//* LIB
import { Suspense } from "react";

//* ROUTERS
import RoutesPage from "./routers";

//* COMPONENTS
import Loading from "./components/Loading";

function App() {
  return (
    <>
      <Suspense fallback={<Loading />}>
        <RoutesPage />
      </Suspense>
    </>
  );
}

export default App;
