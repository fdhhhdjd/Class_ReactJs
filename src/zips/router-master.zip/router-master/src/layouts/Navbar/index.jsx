//* ROUTERS
import NavLinkActive from "@/routers/NavLinkActive";

//* HOOKS
import useAuth from "@/hooks/useAuth";

const Navbar = () => {
  const { user } = useAuth();
  return (
    <>
      <ul>
        {user && (
          <>
            <li>
              <NavLinkActive to="/">Home</NavLinkActive>
            </li>
            <li>
              <NavLinkActive to="/about">About</NavLinkActive>
            </li>
            <li>
              <NavLinkActive to="/contact">Contact</NavLinkActive>
            </li>
          </>
        )}

        {user ? <li>Logout</li> : <li>Login</li>}
      </ul>
    </>
  );
};

export default Navbar;
