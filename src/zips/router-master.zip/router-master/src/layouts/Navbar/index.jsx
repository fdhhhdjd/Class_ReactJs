//* ROUTERS
import NavLinkActive from "@/routers/NavLinkActive";

//* HOOKS
import useAuth from "@/hooks/useAuth";

const Navbar = () => {
  const {
    user,
    handleChangeTheme,
    theme,
    handleSetLocalStorage,
    handleGetLocalStorage,
    handleDeleteLocalStorage,
  } = useAuth();
  return (
    <>
      <button onClick={handleChangeTheme}>
        Change {theme ? "Blue" : "Black"}
      </button>
      <br />

      <button onClick={handleSetLocalStorage}>Set localStorage</button>
      <button onClick={handleGetLocalStorage}>Get localStorage</button>
      <button onClick={handleDeleteLocalStorage}>Delete localStorage</button>
      <ul>
        {user && (
          <>
            <li>
              <NavLinkActive to="/">Home</NavLinkActive>
            </li>
            <li>
              <NavLinkActive to="/about">About</NavLinkActive>
            </li>
            <li>
              <NavLinkActive to="/contact">Contact</NavLinkActive>
            </li>
          </>
        )}

        {user ? <li>Logout</li> : <li>Login</li>}
      </ul>
    </>
  );
};

export default Navbar;
