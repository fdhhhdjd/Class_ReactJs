import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { resolve } from "path";
import { fileURLToPath } from "url";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  // port default
  server: {
    port: 9999,
  },
  resolve: {
    alias: {
      "@": resolve(fileURLToPath(new URL("./src/", import.meta.url))),
    },
  },
});
