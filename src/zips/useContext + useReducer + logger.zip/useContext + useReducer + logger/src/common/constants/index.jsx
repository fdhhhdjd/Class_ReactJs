export const NODE_APP = {
  DEV: "dev",
  PRO: "pro",
};
