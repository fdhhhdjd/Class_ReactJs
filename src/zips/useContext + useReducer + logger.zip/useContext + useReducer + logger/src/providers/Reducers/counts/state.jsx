export const initState = {
  count: 0,
};
