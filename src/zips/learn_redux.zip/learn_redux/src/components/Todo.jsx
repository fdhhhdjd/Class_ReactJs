import { CSSTransition, TransitionGroup } from "react-transition-group";

import "../styles/todo.css";
import { useDispatch } from "react-redux";
import { showToastError, showToastSuccess } from "../utils/toast";
import {
  editTodoError,
  editTodoPending,
  editTodoSuccess,
  removeTodoError,
  removeTodoPending,
  removeTodoSuccess,
} from "../stores/Action";
import { useState } from "react";

const Todo = ({ id, task, completed }) => {
  const dispatch = useDispatch();

  const [edit, setEdit] = useState(false);
  const [editStack, setEditStack] = useState(task);
  const [IdDetail, setIdDetail] = useState();

  const handleEditTodo = (e) => {
    e.preventDefault();
    if (editStack === task) return showToastError("May co sua gi dau 🙂 ");
    try {
      dispatch(editTodoPending());
      setTimeout(() => {
        dispatch(
          editTodoSuccess({
            id: IdDetail,
            task: editStack,
          })
        );
      }, 1000);
    } catch (error) {
      dispatch(editTodoError());
    }
  };

  const handleRemoveTodo = (id) => {
    if (!id) return showToastError("Please enter id 🙃");

    if (window.confirm("Are you sure delete task 🤔")) {
      try {
        dispatch(removeTodoPending());
        setTimeout(() => {
          dispatch(removeTodoSuccess(id));
          showToastSuccess("Delete todos successfully!");
        }, 1300);
      } catch (error) {
        dispatch(removeTodoError());
      }
    }
  };
  const handleFlag = (id) => {
    setEdit((prev) => !prev);
    setIdDetail(id);
  };
  return (
    <>
      <TransitionGroup
        className={completed ? "Todo completed" : "Todo"}
        timeout={500}
      >
        {edit ? (
          <CSSTransition key="editing" timeout={500} classNames="form">
            <form className="Todo-edit-form" onSubmit={handleEditTodo}>
              <input
                type="text"
                name="task"
                value={editStack}
                onChange={(e) => setEditStack(e.target.value)}
              />
              <button>Edit Save</button>
            </form>
          </CSSTransition>
        ) : (
          <CSSTransition key="normal" timeout={500} classNames="task-text">
            <li className="Todo-task">{task}</li>
          </CSSTransition>
        )}
        <div className="Todo-buttons">
          <button onClick={() => handleFlag(id)}>
            {edit ? (
              <i className="fa fa-window-close"></i>
            ) : (
              <i className="fas fa-pen" />
            )}
          </button>

          <button onClick={() => handleRemoveTodo(id)}>
            <i className="fas fa-trash" />
          </button>
        </div>
      </TransitionGroup>
    </>
  );
};

export default Todo;
