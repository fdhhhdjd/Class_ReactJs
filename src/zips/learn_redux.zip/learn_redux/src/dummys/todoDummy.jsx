import { nanoid } from "nanoid";

export const dataTodo = [
  {
    id: nanoid(),
    task: "Nguyễn Tiến Tài",
    completed: false,
  },
  {
    id: nanoid(),
    task: "Nguyễn Bảo khang",
    completed: false,
  },
  {
    id: nanoid(),
    task: "Trần Phi Hoàng",
    completed: true,
  },
  {
    id: nanoid(),
    task: " Nguyễn Hữu Quyền ",
    completed: false,
  },
  {
    id: nanoid(),
    task: "Bùi Huỳnh Quốc Trung",
    completed: false,
  },
];
