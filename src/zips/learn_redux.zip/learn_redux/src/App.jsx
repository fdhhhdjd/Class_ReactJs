import { ToastContainer } from "react-toastify";
import TodoList from "./pages/todos/TodoList";
import "./styles/style.css";
function App() {
  return (
    <>
      <ToastContainer />
      <TodoList />
    </>
  );
}

export default App;
