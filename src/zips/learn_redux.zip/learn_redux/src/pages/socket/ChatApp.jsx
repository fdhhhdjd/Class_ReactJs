import Picker from "emoji-picker-react";
import React, { useEffect, useState } from "react";
import { useSocketContext } from "../../providers/socketContext";
import ChatMessage from "./ChatMessage";
import { dataIcon } from "./data/icon";
import messageTone from "./message-tone.mp3";
import "./style.css";

const MemoEmojiPicker = React.memo(Picker);

const ChatApp = () => {
  const { socket } = useSocketContext();

  const [clientsTotal, setClientsTotal] = useState(0);
  const [messages, setMessages] = useState([]);
  const [typing, setTyping] = useState(false);
  const [message, setMessage] = useState("");
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  const messageContainerRef = React.createRef(null);
  const inputRef = React.createRef("");

  const handleEmojiClick = (emojiObject) => {
    console.log(message);
    let messageNew = message + emojiObject.emoji;
    updateMessage(messageNew);
  };

  const handleEmojiPickerhideShow = () => {
    setShowEmojiPicker(!showEmojiPicker);
  };

  const sendMessage = (e) => {
    e.preventDefault();

    if (message === "") return;

    socket.emit("stop typing");

    const data = {
      name: "Anonymous",
      message: message,
      dateTime: new Date(),
    };

    socket.emit("message", data);
    addMessageToUI(true, data);
    setMessage("");
    setTyping(false);
    setShowEmojiPicker(false);
  };

  const playMessageTone = () => {
    const audio = new Audio(messageTone);
    audio.muted = false; 
    audio.play().catch((err)=>{
      console.log(err);
    })
  };

  const handleClick = () => {
  playMessageTone();
};

  const addMessageToUI = (isOwnMessage, data) => {
    const messageWithAdditionalProps = Object.assign({}, data, {
      id: Date.now(),
      isOwnMessage: isOwnMessage,
    });

    setMessages((prevMessages) => [
      ...prevMessages,
      messageWithAdditionalProps,
    ]);
  };

  const updateMessage = (newMessage) => {
    setMessage(newMessage);
    socket.emit("typing"); // Gửi sự kiện "typing" qua socket
  };

  const handleChange = (e) => {
    updateMessage(e.target.value);
  };

  const scrollToBottom = () => {
    if (messageContainerRef.current) {
      messageContainerRef.current.scrollTop =
        messageContainerRef.current.scrollHeight;
    }
  };

  useEffect(() => {
    socket.on("clients-total", (data) => {
      setClientsTotal(data);
    });

    socket.on("chat-message", (data) => {
      data.id = Date.now();
      handleClick();
      addMessageToUI(false, data);
    });

    socket.on("typing", () => setTyping(true));
    socket.on("stop typing", () => setTyping(false));

    return () => {
      socket.off("clients-total");
      socket.off("chat-message");
    };
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        messageContainerRef.current &&
        messageContainerRef.current.contains(event.target)
      ) {
        setShowEmojiPicker(false);
      }
    };

    document.addEventListener("click", handleClickOutside);

    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  }, [showEmojiPicker]);

  return (
    <div className="main">
      <h3 className="clients-total">Total Clients: {clientsTotal}</h3>
      <ul className="message-container" ref={messageContainerRef}>
        {messages.map((message) => (
          <ChatMessage
            key={message.id}
            isOwnMessage={message.isOwnMessage}
            messageData={message}
          />
        ))}
        {typing && (
          <li className="message-feedback">
            <p className="feedback" id="feedback">
              ✍️ killer is typing a message...
            </p>
          </li>
        )}
      </ul>
      <div className="Picker">
        {showEmojiPicker && (
          <MemoEmojiPicker
            onEmojiClick={handleEmojiClick}
            lazyLoadEmojis={true}
            theme="light"
            customEmojis={dataIcon}
            emojiStyle="google"
          />
        )}
      </div>

      <form className="message-form" onSubmit={sendMessage}>
        {/* <div className="message-form"> */}
        <input
          ref={inputRef}
          type="text"
          name="message"
          id="message-input"
          className="message-input"
          value={message}
          onChange={handleChange}
          onFocus={() => {
            socket.emit("typing");
          }}
          onBlur={() => {
            socket.emit("stop typing");
          }}
        />
        <div className="v-divider"></div>
        <button type="submit" className="send-button">
          <span>
            <i
              className="fa-solid fa-face-smile"
              onClick={handleEmojiPickerhideShow}
            ></i>
          </span>
        </button>
        <div className="v-divider"></div>
        <button type="submit" className="send-button" onClick={sendMessage}>
          send{" "}
          <span>
            <i className="fas fa-paper-plane"></i>
          </span>
        </button>
      </form>
    </div>
  );
};

export default ChatApp;
