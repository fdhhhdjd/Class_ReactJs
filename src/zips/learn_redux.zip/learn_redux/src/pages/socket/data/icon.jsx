export const dataIcon = [
  {
    names: ["Alice", "alice in wonderland"],
    imgUrl:
      "https://cdn.jsdelivr.net/gh/ealush/emoji-picker-react@custom_emojis_assets/alice.png",
    id: "🧑‍🦱",
  },
  {
    names: ["Dog"],
    imgUrl:
      "https://cdn.jsdelivr.net/gh/ealush/emoji-picker-react@custom_emojis_assets/dog.png",
    id: "🐶",
  },
  {
    names: ["Hat"],
    imgUrl:
      "https://cdn.jsdelivr.net/gh/ealush/emoji-picker-react@custom_emojis_assets/hat.png",
    id: "🤠",
  },
  {
    names: ["Kid"],
    imgUrl:
      "https://cdn.jsdelivr.net/gh/ealush/emoji-picker-react@custom_emojis_assets/kid.png",
    id: "🧒",
  },
  {
    names: ["Mic"],
    imgUrl:
      "https://cdn.jsdelivr.net/gh/ealush/emoji-picker-react@custom_emojis_assets/mic.png",
    id: "🎧",
  },
  {
    names: ["Moab", "desert"],
    imgUrl:
      "https://cdn.jsdelivr.net/gh/ealush/emoji-picker-react@custom_emojis_assets/moab.png",
    id: "🇼🇸",
  },
  {
    names: ["Potter", "harry", "harry potter"],
    imgUrl:
      "https://cdn.jsdelivr.net/gh/ealush/emoji-picker-react@custom_emojis_assets/potter.png",
    id: "🧔",
  },
  {
    names: ["Shroom", "mushroom"],
    imgUrl:
      "https://cdn.jsdelivr.net/gh/ealush/emoji-picker-react@custom_emojis_assets/shroom.png",
    id: "🍄",
  },
  {
    names: ["Smily"],
    imgUrl:
      "https://cdn.jsdelivr.net/gh/ealush/emoji-picker-react@custom_emojis_assets/smily.png",
    id: "😃",
  },
  {
    names: ["Tabby", "cat"],
    imgUrl:
      "https://cdn.jsdelivr.net/gh/ealush/emoji-picker-react@custom_emojis_assets/tabby.png",
    id: "😺",
  }
];
