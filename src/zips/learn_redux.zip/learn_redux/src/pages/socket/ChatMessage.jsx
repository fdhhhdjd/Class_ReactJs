import moment from "moment";
import "moment/locale/en-au";
import { memo } from "react";

/* eslint-disable react/prop-types */
const ChatMessage = ({ isOwnMessage, messageData }) => {
  console.log('re-render2',isOwnMessage);
    return (
        <li
        key={messageData.id}
        className={isOwnMessage ? "message-right" : "message-left"}
      >
        <p className="message">
          {messageData.message}
          <span>
            {messageData.name} ● {moment(messageData.dateTime).fromNow()}
          </span>
        </p>
      </li>
    )
}

export default memo(ChatMessage);