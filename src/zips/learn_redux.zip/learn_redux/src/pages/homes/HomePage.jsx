import useStoreTodo from "../../hooks/useTodoList";

const HomePage = () => {
    const { todo } = useStoreTodo()

    console.log(todo);
  return (
    <div>HomePage</div>
  )
}

export default HomePage