import "../../styles/todo_list.css";
import InputTodo from "../../components/InputTodo";
import useStoreTodo from "../../hooks/useTodoList";
import { TransitionGroup, CSSTransition } from "react-transition-group";
import Todo from "../../components/Todo";
import { BeatLoader } from "react-spinners";
import { Fragment, useState } from "react";

const override = {
  display: "block",
  margin: "0 auto",
  borderColor: "red",
};

const TodoList = () => {
  const { todos, loading } = useStoreTodo();
  let [color] = useState("#ffffff");

  return (
    <div className="TodoList">
      <h1>Todo List With React-Redux 😍 </h1>
      <InputTodo />
      {loading ? (
        <BeatLoader
          color={color}
          loading={loading}
          cssOverride={override}
          size={50}
          aria-label="Loading Spinner"
          data-testid="loader"
        />
      ) : (
        <ul>
          <TransitionGroup className="todo=list">
            {todos &&
              todos.map((todo) => {
                return (
                  <Fragment key={todo.id}>
                    <CSSTransition classNames="todo" timeout={500}>
                      <Todo
                        id={todo.id}
                        task={todo.task}
                        completed={todo.completed}
                      />
                    </CSSTransition>
                  </Fragment>
                );
              })}
          </TransitionGroup>
        </ul>
      )}
    </div>
  );
};

export default TodoList;
