import { dataTodo } from "../dummys/todoDummy";
import * as TYPES from "./ActionType";

import { nanoid } from "nanoid";

const initialState = {
  loading: false,
  todos: dataTodo,
  error: null,
};

const TodoReducer = (state = initialState, action) => {
  const { type, payload } = action;
  switch (type) {
    //Todo:  1. Pending
    case TYPES.ADD_TODO_PENDING:
    case TYPES.REMOVE_TODO_PENDING:
    case TYPES.EDIT_TODO_PENDING:
      return {
        ...state,
        loading: true,
      };

    //Todo: 2. Success
    case TYPES.ADD_TODO_SUCCESS:
      const newTodo = {
        id: nanoid(),
        task: payload,
        completed: false,
      };

      const newArray = [...state.todos, newTodo];
      return {
        ...state,
        todos: newArray,
        loading: false,
      };

    case TYPES.REMOVE_TODO_SUCCESS:
      const filterTodo = state.todos.filter((todo) => todo.id !== payload);
      return {
        ...state,
        todos: filterTodo,
        loading: false,
      };

    case TYPES.EDIT_TODO_SUCCESS:
      const newData = state.todos.map((todo) => {
        if (todo.id === payload.id) {
          return { ...todo, task: payload.task };
        }
        return todo;
      });
      return {
        ...state,
        todos: newData,
        loading: false,
      };

    //Todo: 3. Error
    case TYPES.ADD_TODO_ERROR:
    case TYPES.REMOVE_TODO_ERROR:
    case TYPES.EDIT_TODO_ERROR:
      return {
        ...state,
        loading: false,
        error: payload,
      };
    default:
      return {
        ...state,
      };
  }
};
export default TodoReducer;
