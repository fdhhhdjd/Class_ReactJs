import ReactDOM from "react-dom/client";
import { Provider } from "react-redux";
import App from "./App.jsx";
import "./index.css";
import store from "./stores/Store.jsx";
import "react-toastify/dist/ReactToastify.css";
// import { DataProvider } from "./providers/socketContext.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <Provider store={store}>
    {/* <DataProvider> */}
    <App />
    {/* </DataProvider> */}
  </Provider>
);
