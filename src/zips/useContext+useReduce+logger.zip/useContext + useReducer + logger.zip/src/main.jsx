//* LIB
import ReactDOM from "react-dom/client";
import { BrowserRouter as Router } from "react-router-dom";

//* IMPORT
import App from "./App.jsx";
import GlobalProviderContext from "./providers/contexts/GlobalContext.jsx";
import "./styles/index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <Router>
    <GlobalProviderContext>
      <App />
    </GlobalProviderContext>
  </Router>
);
