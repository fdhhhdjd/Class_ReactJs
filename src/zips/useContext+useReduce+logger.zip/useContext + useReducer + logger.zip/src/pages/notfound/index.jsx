import React from "react";

const NotFoundPage = () => {
  return (
    <React.Fragment>
      <h1>Not Found</h1>
    </React.Fragment>
  );
};

export default NotFoundPage;
