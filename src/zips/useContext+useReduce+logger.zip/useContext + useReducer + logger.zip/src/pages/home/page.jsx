//* LIB
import React from "react";

//* IMPORT
import { incrementAction } from "@/providers/Reducers/counts/actions";
import { useGlobalContext } from "@/providers/contexts/GlobalContext";

const HomePage = () => {
  const {
    state: { count },
    dispatch,
  } = useGlobalContext();

  const handleIncrementCount = () => {
    dispatch(incrementAction(count));
  };
  return (
    <React.Fragment>
      <h1>Hello Home Page Tài heo</h1>
      <h1>{count}</h1>
      <button onClick={handleIncrementCount}>Increment +</button>
    </React.Fragment>
  );
};

export default HomePage;
