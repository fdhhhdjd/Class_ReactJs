//* LIB
import { useRoutes } from "react-router-dom";

//* IMPORT
import Navbar from "@/components/Navbar";
import AboutPage from "@/pages/about/page";
import HomePage from "@/pages/home/page";
import NotFoundPage from "@/pages/notfound";

const Routes = () => {
  let elements = useRoutes([
    {
      path: "/",
      element: <Navbar />,
      children: [
        {
          index: true,
          element: <HomePage />,
        },
        {
          path: "about",
          element: <AboutPage />,
        },
      ],
    },
    {
      path: "*",
      element: <NotFoundPage />,
    },
  ]);

  return elements;
};

export default Routes;
