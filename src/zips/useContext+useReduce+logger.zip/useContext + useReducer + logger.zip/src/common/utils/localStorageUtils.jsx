// Save data into localStorage
export const setItem = (key, value) => {
  localStorage.setItem(key, JSON.stringify(value));
};

// Get data for localStorage
export const getItem = (key) => {
  const item = localStorage.getItem(key);
  return item ? JSON.parse(item) : null;
};

// remove every item into localStorage
export const removeItem = (key) => {
  localStorage.removeItem(key);
};

// Remove all data in localStorage
export const clearStorage = () => {
  localStorage.clear();
};

// Check item exists in localStorage
export const hasItem = (key) => {
  return localStorage.getItem(key) !== null;
};
