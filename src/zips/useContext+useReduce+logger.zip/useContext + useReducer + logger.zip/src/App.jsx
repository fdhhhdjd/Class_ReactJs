//* LIB
import React from "react";

//* IMPORT
import Routes from "@/routers/routes";
import "@/styles/App.css";

function App() {
  return (
    <React.Fragment>
      <Routes />
    </React.Fragment>
  );
}

export default App;
