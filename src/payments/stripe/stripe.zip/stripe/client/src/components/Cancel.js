import React from 'react'

const Cancel = () => {
  return (
    <div>Cancel</div>
  )
}

export default Cancel