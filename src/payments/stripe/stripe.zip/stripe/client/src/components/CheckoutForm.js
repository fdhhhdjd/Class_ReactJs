import React, { useState, useEffect } from 'react';
import { loadStripe } from '@stripe/stripe-js';

const CheckoutForm = () => {
  const [stripe, setStripe] = useState(null);

  useEffect(() => {
    // Load Stripe.js outside of components’ render to avoid
    // recreating the `Stripe` object on every render.
    const loadStripeInstance = async () => {
      const stripe = await loadStripe(process.env.REACT_APP_PUBLIC_KEY);
      setStripe(stripe);
    };

    loadStripeInstance();
  }, []);

  const handleSubmit = async (event) => {
    event.preventDefault();

    // Thực hiện xử lý thanh toán ở đây, ví dụ: tạo Intent thanh toán trên máy chủ của bạn và nhận về clientSecret
    const response = await fetch('YOUR_SERVER_PAYMENT_ENDPOINT', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ amount: 1000, currency: 'usd' }), // Thay đổi giá trị và tiền tệ tùy theo yêu cầu của bạn
    });
    const { clientSecret } = await response.json();

    // Confirm the card payment
    const result = await stripe.confirmCardPayment(clientSecret, {
      payment_method: {
        card: elements.getElement(CardElement),
        billing_details: {
          name: 'Jenny Rosen',
        },
      },
    });

    if (result.error) {
      console.error(result.error.message);
    } else {
      // Thanh toán thành công, xử lý logic tiếp theo ở đây
      console.log('Payment successful');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      {/* Giao diện của bạn cho các trường thông tin thanh toán, ví dụ: */}
      <div>
        <label>
          Card details
          <CardElement options={CARD_ELEMENT_OPTIONS} />
        </label>
      </div>

      <button type="submit" disabled={!stripe}>
        Pay
      </button>
    </form>
  );
};

export default CheckoutForm;
