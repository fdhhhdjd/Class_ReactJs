require("dotenv").config();
const express = require("express");
const app = express();
const cors = require("cors");
const stripe = require("stripe")(process.env.STRIPE_SECRET);

app.use(express.json());
app.use(cors());

// checkout api
app.post("/api/create-checkout-session",async(req,res)=>{
    const {products} = req.body;


    const lineItems = products.map((product)=>({
        price_data:{
            currency:"vnd",
            product_data:{
                name:product.dish,
                images:[product.imgdata]
            },
            unit_amount:product.price * 100,
        },
        quantity:product.qnty
    }));

    const session = await stripe.checkout.sessions.create({
        payment_method_types:["card"],
        line_items:lineItems,
        mode:"payment",
        success_url:"http://localhost:3000/sucess",
        cancel_url:"http://localhost:3000/cancel",
    });

    res.json({id:session.id})
 
})
// checkout api
app.post("/api/create-payment-intent", async (req, res) => {
    try {
        console.log(req.body.token);
      const paymentIntent = await stripe.paymentIntents.create({
        amount: 1099,
        currency: "eur",
        automatic_payment_methods: {
          enabled: true
        },
      });
      console.log(paymentIntent);
      return res.status(200).json({ clientSecret: paymentIntent.client_secret });
    } catch (error) {
      console.error('Error processing payment:', error);
      res.status(500).send({ error: 'Error processing payment' });
    }
  });
  


app.listen(7000,()=>{
    console.log("server start")
})