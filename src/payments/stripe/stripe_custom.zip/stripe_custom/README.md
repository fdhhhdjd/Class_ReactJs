# How to install and run

Follow the instructions in each README for the `client` and `server`.
