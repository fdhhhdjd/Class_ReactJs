function Completion(props) {
  return <h1>Thank you! 🎉</h1>;
}

export default Completion;
