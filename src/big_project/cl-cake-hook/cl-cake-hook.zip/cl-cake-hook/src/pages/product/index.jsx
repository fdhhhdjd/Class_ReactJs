import { getProductSuccess } from '@/providers/reducer/products/action';
import productReducer, { initState } from '@/providers/reducer/products/reducer';
import { useEffect, useReducer } from 'react';
import CartProductItem from './CartProductItem';

const Product = () => {
  const [state, dispatch] = useReducer(productReducer, initState);

  const { products } = state;
  useEffect(() => {
    dispatch(getProductSuccess());
  }, []);

  return (
    <>
      <section id="products" className="container mx-auto">
        <div className="section-style-one new-products mb-[60px]">
          <div className="section-wrapper w-full">
            <div className="container-x mx-auto">
              <div className="section-title flex justify-between items-center mb-5">
                <div>
                  <h1 className="sm:text-3xl text-xl font-600 text-black leading-none">
                    List Products
                  </h1>
                </div>
              </div>

              {/* List Products */}
              <div className="section-content">
                <div className="products-section w-full">
                  <div className="grid xl:grid-cols-4 lg:grid-cols-3 sm:grid-cols-2 grid-cols-1 xl:gap-[30px] gap-5">
                    {/* Mapping qua danh sách sản phẩm */}
                    {products.map((product) => (
                      <div
                        key={product.id}
                        data-aos="fade-up"
                        className="item aos-init aos-animate"
                      >
                        {/* CartProductItem Component */}
                        <CartProductItem product={product} />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
export default Product;
