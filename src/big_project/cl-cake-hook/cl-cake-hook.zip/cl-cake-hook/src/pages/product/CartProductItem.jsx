import { useCart } from '@/contexts';
import { addToCart } from '@/providers/reducer/carts/action';
import { Link } from 'react-router-dom';
import { getImage } from '../../utils';

function CartProductItem({ product }) {
  const { dispatch } = useCart();

  const addToCartHandler = (id) => {
    dispatch(addToCart({ productId: id }));
  };

  return (
    <div
      className="w-full h-full bg-white relative group overflow-hidden"
      style={{ boxShadow: '0px 15px 64px 0px rgba(0, 0, 0, 0.05)' }}
    >
      {/* Card Image */}
      <div className="w-full h-[250px]">
        <img
          src={getImage(product.image_url)}
          alt=""
          className="bg-image h-full object-contain bg-center bg-no-repeat w-9/12 mx-auto transition-all duration-200 group-hover:scale-110"
        />
      </div>

      {/* Card content */}
      <div className="px-10 pb-14 relative mt-8">
        <div className="hidden lg:block top-60 group-hover:top-[155px] absolute w-full h-10 px-[30px] left-0 transition-all duration-300 ease-in-out">
          <button
            type="button"
            className="bg-yellow-500 w-full py-2 px-4 rounded-lg"
            onClick={() => addToCartHandler(product.id)}
          >
            <div className="flex items-center space-x-3">
              <span>
                {' '}
                <i className="fa-solid fa-bag-shopping" />{' '}
              </span>
              <span>Add To Cart</span>
            </div>
          </button>
        </div>

        {/* Reviews */}
        <div className="reviews flex space-x-[1px] mb-3">
          <span>
            <i className="fa-solid fa-star" style={{ color: '#ffa800' }} />
          </span>
          <span>
            <i className="fa-solid fa-star" style={{ color: '#ffa800' }} />
          </span>
          <span>
            <i className="fa-solid fa-star" style={{ color: '#ffa800' }} />
          </span>
        </div>

        {/* Title name Product */}
        <Link to={`/product/${product.id}`}>
          <p className="title mb-2 text-[15px] font-600 text-black leading-[24px] line-clamp-2 hover:text-yellow cursor-pointer">
            <b>Name</b>: {product.name}
          </p>
          <p className="title mb-2 text-[15px] font-600 text-black leading-[24px] line-clamp-2 hover:text-yellow cursor-pointer">
            <b>Des</b>: {product.description}
          </p>
        </Link>

        <div className="price">
          <b className="mr-1">Price:</b>
          <span
            className={product.discounted_price ? 'line-through ' : ''}
            style={{ fontSize: '18px', marginRight: '2px' }}
          >
            ${product.original_price}
          </span>

          {product.discounted_price && <span>-</span>}

          <span
            className={product.discounted_price ? 'text-red-500' : ''}
            style={{ fontSize: '18px', marginLeft: '2px' }}
          >
            {product.discounted_price ? product.discounted_price : ''}
          </span>
        </div>

        <div className="flex lg:hidden justify-end">
          <button
            type="button"
            className="bg-yellow-500 py-2 px-4 rounded-lg cursor-pointer"
            onClick={() => addToCartHandler(product.id)}
          >
            <div className="flex items-center space-x-3">
              <span>
                {' '}
                <i className="fa-solid fa-cart-shopping"></i>{' '}
              </span>
            </div>
          </button>
        </div>
      </div>
      <div className="flex flex-col space-y-2 absolute group-hover:right-4 -right-10 top-20 transition-all duration-300 ease-in-out">
        <span className="w-10 h-10 flex justify-center items-center bg-gray-100 rounded">
          <i className="fa-solid fa-expand" />
        </span>

        <span className="w-10 h-10 flex justify-center items-center bg-gray-100 rounded">
          <i className="fa-regular fa-heart" />
        </span>
        <span className="w-10 h-10 flex justify-center items-center bg-gray-100 rounded">
          <i className="fa-solid fa-arrows-rotate" />
        </span>
      </div>
    </div>
  );
}

export default CartProductItem;
