import EmptyOrder from '@/components/empty/EmptyOrder';
import { useCart } from '@/contexts';
import OrderList from '@/components/OrderCarts';

const Orders = () => {
  const { stateOrder } = useCart();

  return <>{stateOrder.order.length === 0 ? <EmptyOrder /> : <OrderList />}</>;
};

export default Orders;
