import CartItem from '@/components/cartItem/CartItem';
import InfoPaying from '@/components/cartItem/InfoPaying';
import EmptyCart from '@/components/empty';
import { useCart } from '@/contexts';

const CartPage = () => {
  const { state } = useCart();
  return (
    <section className="wrap-cart">
      <div className="w-full">
        <div className="container mx-auto">
          {state.cart.length === 0 ? (
            // No data cart
            <EmptyCart />
          ) : (
            // Cart exists
            <>
              <CartItem />
              <InfoPaying />
            </>
          )}
        </div>
      </div>
    </section>
  );
};

export default CartPage;
