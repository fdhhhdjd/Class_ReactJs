import React from 'react';
import { NavLink } from 'react-router-dom';
import '@/styles/Navbar.css'; // Đảm bảo import file CSS

const Navbar = () => {
  return (
    <div className="h-full flex justify-between items-center">
      <div className="category-and-nav flex xl:space-x-7 space-x-3 items-center">
        <div className="nav">
          <ul className="nav-wrapper flex xl:space-x-10 space-x-5">
            <li className="relative">
              <NavLink
                to="/"
                className={({ isActive }) =>
                  isActive
                    ? 'flex items-center text-lg font-600 cursor-pointer text-black router-link-active router-link-exact-active'
                    : 'flex items-center text-lg font-600 cursor-pointer text-black'
                }
              >
                <span>Products</span>
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/cart"
                className={({ isActive }) =>
                  isActive
                    ? 'flex items-center text-lg font-600 cursor-pointer text-black router-link-active router-link-exact-active'
                    : 'flex items-center text-lg font-600 cursor-pointer text-black'
                }
              >
                <span>Carts</span>
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/order"
                className={({ isActive }) =>
                  isActive
                    ? 'flex items-center text-lg font-600 cursor-pointer text-black router-link-active router-link-exact-active'
                    : 'flex items-center text-lg font-600 cursor-pointer text-black'
                }
              >
                <span>Orders</span>
              </NavLink>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
