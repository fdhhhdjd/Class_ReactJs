// Todo: DEFAULT
export const DEFAULT = 'CL Cake Shop';

// Todo: PRODUCTS
export const PRODUCTS = {
  LIST: 'List Product',
  DETAIL: 'Product Detail',
};

// Todo: CARTS
export const CARTS = {
  LIST: 'Cart',
};

// Todo: ORDERS
export const ORDERS = {
  LIST: 'Order',
};
