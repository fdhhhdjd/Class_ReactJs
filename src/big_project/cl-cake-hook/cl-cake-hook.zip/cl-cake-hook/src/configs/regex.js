// TODO: Regular expression to match placeholders in a string.
export const REGEX_IS_STRING_PARAM = /\${(\w+)}/g;
