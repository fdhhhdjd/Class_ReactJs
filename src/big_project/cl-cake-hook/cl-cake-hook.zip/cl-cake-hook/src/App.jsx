//* ReactJS
import React, { Fragment, Suspense } from 'react';

//* Library
import { Route, Routes } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import NotFound from '@/pages/notfound';
import Loading from '@/components/loading';
import Header from '@/components/header';
import Product from '@/pages/product';
import ProductDetail from './components/productDetail';
import CartPage from './pages/cart';
import ThankYouPage from './pages/thankyou';
import OrdersPage from './pages/order';

//* Pages

function App() {
  return (
    <Fragment>
      <Suspense fallback={<Loading />}>
        <ToastContainer position="top-center" />
        <Header />
        <div className="mt-32">
          <Routes>
            <Route path="/" element={<Product />} />
            <Route path="/product/:id" element={<ProductDetail />} />
            <Route path="/cart" element={<CartPage />} />
            <Route path="/order" element={<OrdersPage />} />
            <Route path="/thankyou" element={<ThankYouPage />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </div>
      </Suspense>
    </Fragment>
  );
}

export default App;
