import { getALlCart } from '@/providers/reducer/carts/action';
import cartReducer, { initState } from '@/providers/reducer/carts/reducer';
import orderReducer, { initStateOrder } from '@/providers/reducer/orders/reducer';
import { getFromLocalStorage } from '@/utils/localstorage';
import React, { createContext, useContext, useEffect, useReducer, useState } from 'react';

const CartContext = createContext();

export const useCart = () => {
  return useContext(CartContext);
};

export const CartProvider = ({ children }) => {
  const [state, dispatch] = useReducer(cartReducer, initState);
  const [stateOrder, dispatchOrder] = useReducer(orderReducer, initStateOrder);

  useEffect(() => {
    dispatch(getALlCart());
  }, [state.cartUpdate]);
  return (
    <CartContext.Provider value={{ state, dispatch, stateOrder, dispatchOrder }}>
      {children}
    </CartContext.Provider>
  );
};
