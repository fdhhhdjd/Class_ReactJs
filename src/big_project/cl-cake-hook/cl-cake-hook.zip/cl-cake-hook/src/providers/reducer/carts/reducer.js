import {
  ADD_TO_CART,
  ADD_TO_CART_MUTING_QUANTITY,
  CLEAR_CART,
  DECREMENT_QUANTITY,
  DELETE_TO_CART,
  GET_ALL_CART,
  INCREMENT_QUANTITY,
} from './type';

//* UTILS
import { ERROR, INFO, SUCCESS } from '@/configs';
import {
  calculationTotalCart,
  calculationTotalCostCart,
  checkExistingProduct,
  deleteOneId,
  flatArrayAndGetProductFlowId,
  getURIFromTemplate,
} from '@/utils';
import {
  getFromLocalStorage,
  removeFromLocalStorage,
  saveToLocalStorage,
} from '@/utils/localstorage';
import { showErrorToast, showInfoToast, showSuccessToast } from '@/utils/toast';

export const initState = {
  cart: getFromLocalStorage('cart') || [],
  total: getFromLocalStorage('total') || 0,
  cost: getFromLocalStorage('cost') || 0,
  cartUpdate: false,
};

const cartReducer = (state, action) => {
  switch (action.type) {
    case ADD_TO_CART:
      const productIdToAdd = action.payload;

      const existingProductToAdd = checkExistingProduct(state.cart, productIdToAdd);

      const isQuantityExceedingStock =
        existingProductToAdd?.quantity >= existingProductToAdd?.stock_count;

      if (isQuantityExceedingStock) {
        // Show toast info
        showInfoToast(INFO.QUANTITY_THAN_STOCK);
        return { ...state };
      }

      if (!existingProductToAdd) {
        const foundProductToAdd = flatArrayAndGetProductFlowId(productIdToAdd);

        if (foundProductToAdd) {
          const productToAdd = {
            ...foundProductToAdd,
            quantity: 1,
          };

          state.cart.push(productToAdd);

          showSuccessToast(
            getURIFromTemplate(SUCCESS.ADD_TO_CART, { nameProduct: productToAdd.name })
          );
          saveToLocalStorage('cart', state.cart);
        } else {
          showErrorToast(ERROR.ADD_TO_CART);
          return state;
        }
      } else {
        existingProductToAdd.quantity += 1;
        showSuccessToast(
          getURIFromTemplate(SUCCESS.ADD_INCREASE_CART, {
            nameProduct: existingProductToAdd.name,
            quantity: existingProductToAdd.quantity,
          })
        );
      }

      saveToLocalStorage('cart', state.cart);

      // Calculate total
      state.total = calculationTotalCart(state.cart); // Recalculate the total quantity of items in the cart.

      // Calculate cost
      state.cost = calculationTotalCostCart(state.cart); // Recalculate the total cost of the items in the cart.

      state.cartUpdate = !state.cartUpdate;

      return { ...state };

    case INCREMENT_QUANTITY:
      state.loading = false;
      const productIdToIncrement = action.payload;
      const existingProductToIncrement = checkExistingProduct(state.cart, productIdToIncrement);

      if (existingProductToIncrement) {
        const isQuantityExceedingStock =
          existingProductToIncrement.quantity >= existingProductToIncrement.stock_count;

        if (isQuantityExceedingStock) {
          showInfoToast(INFO.QUANTITY_THAN_STOCK);
          return state;
        }

        existingProductToIncrement.quantity += 1;
      }

      saveToLocalStorage('cart', state.cart);

      state.cartUpdate = !state.cartUpdate;

      return {
        ...state,
      };

    case DECREMENT_QUANTITY:
      state.loading = false; // Set loading state to false.

      const productIdToDecrement = action.payload; // Get the productId from the payload of the action.

      const existingProductToDecrement = state.cart.find(
        (product) => product.id === productIdToDecrement
      );

      if (existingProductToDecrement) {
        const isQuantityGreaterThanOne = existingProductToDecrement.quantity > 1;

        if (isQuantityGreaterThanOne) {
          existingProductToDecrement.quantity -= 1;
        } else {
          state.cart = deleteOneId(state.cart, productIdToDecrement);
          showWarningToast(WARNING.DELETE_PRODUCT);
        }
      }

      saveToLocalStorage('cart', state.cart);
      state.cartUpdate = !state.cartUpdate;

      return {
        ...state,
        total: calculationTotalCart(state.cart),
        cost: calculationTotalCostCart(state.cart),
      };

    case ADD_TO_CART_MUTING_QUANTITY:
      state.loading = false; // Set loading state to false.

      const { productId, quantity } = action.payload; // Get the productId and quantity from the payload of the action.

      const existingProduct = checkExistingProduct(state.cart, productId); // Check if the product already exists in the cart.

      if (!existingProduct) {
        // If the product does not already exist in the cart:
        const foundProduct = flatArrayAndGetProductFlowId(productId); // Attempt to find the product information based on its productId.

        const productToAdd = {
          ...foundProduct,
          quantity: quantity || 1, // If found, create a new cart item with quantity set to 1.
        };

        state.cart.push(productToAdd); // Add the new item to the cart.

        const resultMessage = getURIFromTemplate(SUCCESS.ADD_TO_CART, {
          nameProduct: productToAdd.name,
        });

        showSuccessToast(resultMessage);
      } else {
        // If the product already exists in the cart:
        const checkQuantityThanStock =
          existingProduct.quantity + quantity > existingProduct.stock_count;

        if (checkQuantityThanStock) {
          // Show toast info
          showInfoToast(INFO.QUANTITY_THAN_STOCK);
          return {
            ...state,
          };
        }
        existingProduct.quantity += quantity;

        const resultMessage = getURIFromTemplate(SUCCESS.ADD_INCREASE_CART, {
          nameProduct: existingProduct.name,
          quantity: existingProduct.quantity,
        });

        showSuccessToast(resultMessage);
      }
      state.cartUpdate = !state.cartUpdate;

      saveToLocalStorage('cart', state.cart);

      // Calculate total
      state.total = calculationTotalCart(state.cart); // Recalculate the total quantity of items in the cart.

      // Calculate cost
      state.cost = calculationTotalCostCart(state.cart); // Recalculate the total cost of the items in the cart.

      return {
        ...state,
      };

    case DELETE_TO_CART:
      state.loading = false; // Set loading state to false.

      const productIdToDelete = action.payload; // Get the productId from the payload of the action.

      state.cart = deleteOneId(state.cart, productIdToDelete);
      // Update the cart state by removing the item with the specified productId.

      saveToLocalStorage('cart', state.cart); // Save updated cart to Local Storage.
      state.cartUpdate = !state.cartUpdate;

      return { ...state };

    case CLEAR_CART:
      removeFromLocalStorage('cart');
      removeFromLocalStorage('total');
      removeFromLocalStorage('cost');

      state.cartUpdate = !state.cartUpdate;
      return {
        cart: getFromLocalStorage('cart') || [],
        total: getFromLocalStorage('total') || 0,
        cost: getFromLocalStorage('cost') || 0,
        cartUpdate: false,
      };

    case GET_ALL_CART:
      return {
        ...state,
      };

    default:
      return state;
  }
};

export default cartReducer;
