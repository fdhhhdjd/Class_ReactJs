//* API
import {
  ADD_TO_CART,
  ADD_TO_CART_MUTING_QUANTITY,
  CLEAR_CART,
  DECREMENT_QUANTITY,
  DELETE_TO_CART,
  GET_ALL_CART,
  INCREMENT_QUANTITY,
} from './type';

// Todo: Add To Cart
export const addToCart = ({ productId }) => {
  return {
    type: ADD_TO_CART,
    payload: productId,
  };
};

// Todo: Get All
export const getALlCart = () => {
  return {
    type: GET_ALL_CART,
  };
};

// Todo: Increment
export const incrementCart = ({ productId }) => {
  return {
    type: INCREMENT_QUANTITY,
    payload: productId,
  };
};

// Todo: Delete
export const deleteToCart = ({ productId }) => {
  return {
    type: DELETE_TO_CART,
    payload: productId,
  };
};

// Todo: Decrement
export const decrementCart = ({ productId }) => {
  return {
    type: DECREMENT_QUANTITY,
    payload: productId,
  };
};

// Todo: Add To Cart MutingQuantity
export const addToCartMutingQuantity = ({ productId, quantity }) => {
  return {
    type: ADD_TO_CART_MUTING_QUANTITY,
    payload: {
      productId,
      quantity,
    },
  };
};

// Todo: Delete all
export const deleteAllCart = () => {
  return {
    type: CLEAR_CART,
  };
};
