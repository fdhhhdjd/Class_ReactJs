import {
  CLEAR_DETAIL_PRODUCT_SUCCESS,
  GET_PRODUCT_DETAIL_SUCCESS,
  GET_PRODUCT_SUCCESS,
} from './type';

//* API
import API_JSON from '../../../api/json/products.json';

export const initState = {
  products: [],
  productDetail: null,
};

const productReducer = (state, action) => {
  switch (action.type) {
    case GET_PRODUCT_SUCCESS:
      return {
        ...state,
        products: action.payload,
      };
    case GET_PRODUCT_DETAIL_SUCCESS:
      return {
        ...state,
        productDetail: API_JSON.find((product) => product.id === action.payload),
      };
    case CLEAR_DETAIL_PRODUCT_SUCCESS:
      return {
        ...state,
        productDetail: null,
      };
    default:
      return state;
  }
};

export default productReducer;
