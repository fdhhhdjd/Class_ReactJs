import {
  GET_PRODUCT_DETAIL_SUCCESS,
  GET_PRODUCT_SUCCESS,
  CLEAR_DETAIL_PRODUCT_SUCCESS,
} from './type';

//* API
import API_JSON from '../../../api/json/products.json';

// Todo: Get Products

export const getProductSuccess = () => {
  return {
    type: GET_PRODUCT_SUCCESS,
    payload: API_JSON,
  };
};

// Todo: Product Detail

export const getProductDetailSuccess = ({ id }) => {
  return {
    type: GET_PRODUCT_DETAIL_SUCCESS,
    payload: id,
  };
};

export const clearDetailProduct = () => {
  return {
    type: CLEAR_DETAIL_PRODUCT_SUCCESS,
  };
};
