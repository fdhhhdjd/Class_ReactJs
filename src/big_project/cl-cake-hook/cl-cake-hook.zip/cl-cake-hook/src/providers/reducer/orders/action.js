import { CREATE_ORDER } from './type';

// Todo: Create order

export const createOrderSuccess = (cart) => {
  return {
    type: CREATE_ORDER,
    payload: cart,
  };
};
