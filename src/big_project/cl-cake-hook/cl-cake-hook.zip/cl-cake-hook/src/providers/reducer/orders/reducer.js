import { CREATE_ORDER } from './type';

export const initStateOrder = {
  order: [],
};

const orderReducer = (state, action) => {
  switch (action.type) {
    case CREATE_ORDER:
      return {
        ...state,
        order: [...state.order, action.payload],
      };
    default:
      return state;
  }
};

export default orderReducer;
