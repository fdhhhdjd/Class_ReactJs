//*  ReactJs
import React from 'react';
import ReactDOM from 'react-dom/client';

//* App
import App from './App.jsx';

//* Css Library
import 'react-toastify/dist/ReactToastify.css';
import './index.css';

//* LIBRARY
import { BrowserRouter as Router } from 'react-router-dom';
import { CartProvider } from './contexts/index.jsx';

ReactDOM.createRoot(document.getElementById('root')).render(
  <Router>
    <CartProvider>
      <App />
    </CartProvider>
  </Router>
);
