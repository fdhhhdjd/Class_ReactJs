import { useCart } from '@/contexts';
import { deleteAllCart } from '@/providers/reducer/carts/action';
import { createOrderSuccess } from '@/providers/reducer/orders/action';
import PropTypes from 'prop-types';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import runFireworks from '../../utils/fireWorks';

const Confirmation = ({ showConfirmation, hideOrderConfirmation, valueNote }) => {
  const [isConfirmationVisible, setConfirmationVisible] = useState(showConfirmation);
  const { dispatchOrder, dispatch, state } = useCart();

  const navigate = useNavigate();

  const confirmOrder = async () => {
    // Create order for cart
    const newObjectCart = { ...state, note: valueNote };

    await dispatchOrder(createOrderSuccess(newObjectCart));

    // Clear cart if create order success
    dispatch(deleteAllCart());

    // Redirect if checkout success
    navigate('/thankyou');

    // Run fireworks
    runFireworks();

    // Hide Popup confirm
    hideOrderConfirmation();
  };

  const handleClickOutside = (event) => {
    if (!event.target.closest('.confirmation-box')) {
      hideOrderConfirmation();
    }
  };

  const handleConfirmationVisibility = () => {
    hideOrderConfirmation();
  };

  return (
    <div>
      {isConfirmationVisible && (
        <div
          className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50"
          onClick={handleClickOutside}
        >
          <div
            style={{
              transform: isConfirmationVisible ? 'scale(1)' : 'scale(0.8)',
              opacity: isConfirmationVisible ? 1 : 0,
            }}
            className="bg-white p-16 rounded shadow-md confirmation-box"
            onClick={(e) => {
              e.stopPropagation();
            }}
          >
            <h2 className="text-2xl font-bold mb-4 text-black">Confirm Your Orders</h2>
            <span className="text-black">Please review your order 😊</span>
            <div className="flex space-x-4 mt-4">
              <button className="px-4 py-2 bg-green-500 text-white rounded" onClick={confirmOrder}>
                Place Order
              </button>
              <button
                className="px-4 py-2 bg-red-500 text-white rounded"
                onClick={handleConfirmationVisibility}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

Confirmation.propTypes = {
  showConfirmation: PropTypes.bool.isRequired,
  hideOrderConfirmation: PropTypes.func.isRequired,
  valueNote: PropTypes.string.isRequired,
};

export default Confirmation;
