import React from 'react';
import OrderCardListProduct from './OrderCardListProduct';
import Summary from './Summary/Summary';
import CustomerOrder from './CustomerOrder/CustomerOrder';
import { useCart } from '@/contexts';
import Note from './Note/Note';

const index = () => {
  const { stateOrder } = useCart();

  return (
    <>
      <div className="py-14 px-4 md:px-6 2xl:px-20 2xl:container 2xl:mx-auto">
        {stateOrder?.order.map((order, index) => (
          <div key={order.id} className="mb-10">
            <div className="flex justify-start items-start space-y-2 flex-col">
              <h1 className="text-3xl lg:text-4xl font-semibold leading-7 lg:leading-9 text-gray-800">
                Order - {+index + 1}
              </h1>
            </div>
            <div className="mt-10 flex flex-col xl:flex-row justify-center items-stretch w-full xl:space-x-8 space-y-4 md:space-y-6 xl:space-y-0">
              <div className="flex flex-col justify-start items-start w-full space-y-4 md:space-y-6 xl:space-y-8">
                <OrderCardListProduct orderItem={order?.cart} />

                {/* Note */}
                <Note noteItem={order} />
                <div className="flex justify-center flex-col md:flex-row items-stretch w-full space-y-4 md:space-y-0 md:space-x-6 xl:space-x-8">
                  <Summary orderItem={order} />
                </div>
              </div>

              {/* Customer Info Order */}
              <div className="lg:self-start">
                {/* Customer Info Order */}
                <CustomerOrder />
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default index;
