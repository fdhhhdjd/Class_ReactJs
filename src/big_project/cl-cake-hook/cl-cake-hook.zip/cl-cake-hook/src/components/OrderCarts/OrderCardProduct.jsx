import { Link } from 'react-router-dom';
import { getImage } from '../../utils';

function OrderItem({ orderItem }) {
  return (
    <div className="mt-4 md:mt-6 flex flex-col md:flex-row justify-start items-start md:items-center md:space-x-6 xl:space-x-8 w-full">
      <div className="pb-4 md:pb-8 w-40">
        <img className="w-full" src={getImage(orderItem.image_url)} alt="dress" />
      </div>
      <div className="border-b border-gray-200 md:flex-row flex-col flex justify-between items-start w-full pb-8 space-y-4 md:space-y-0">
        <div className="w-full flex flex-col justify-start items-start space-y-8">
          <Link to={`/product/${orderItem.id}`}>
            <span className="text-xl text-yellow-500">Name</span>
            <h3 className="text-xl xl:text-2xl font-semibold leading-6 text-gray-800">
              {orderItem.name}
            </h3>
          </Link>
        </div>
        <div className="flex justify-between space-x-8 items-start w-full">
          <div className="w-full flex flex-col justify-start items-start space-y-8">
            <span className="text-xl text-yellow-500">Original</span>
            <p className="text-base dark:text-gray xl:text-lg leading-6">
              <span className={orderItem.is_on_discount ? 'line-through' : ''}>
                ${orderItem.original_price}
              </span>
              {orderItem.is_on_discount && (
                <span className="text-red-500"> - ${orderItem.discounted_price}</span>
              )}
            </p>
          </div>
          <div className="w-full flex flex-col justify-start items-start space-y-8">
            <span className="text-xl text-yellow-500">Quantity</span>
            <p className="text-xl:text-lg leading-6 text-gray-800">{orderItem.quantity}</p>
          </div>
          <div className="w-full flex flex-col justify-start items-start space-y-8">
            <span className="text-xl text-yellow-500">Price</span>
            <p className="text-base xl:text-lg font-semibold leading-6 text-gray-800">
              ${orderItem.quantity * (orderItem.discounted_price || orderItem.original_price)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default OrderItem;
