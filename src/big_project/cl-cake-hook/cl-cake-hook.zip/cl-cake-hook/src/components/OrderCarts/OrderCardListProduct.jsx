import OrderCardProduct from './OrderCardProduct';

function OrderList({ orderItem }) {
  return (
    <div className="flex flex-col justify-start items-start bg-gray-50 px-4 py-4 md:py-6 md:p-6 xl:p-8 w-full">
      {orderItem.map((order) => (
        <OrderCardProduct key={order.id} orderItem={order} />
      ))}
    </div>
  );
}

export default OrderList;
