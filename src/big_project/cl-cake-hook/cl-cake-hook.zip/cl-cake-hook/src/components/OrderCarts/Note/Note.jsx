function NoteComponent({ noteItem }) {
  return (
    <div className="flex flex-col px-4 py-6 md:p-6 xl:p-8 w-full bg-gray-50 space-y-6">
      <h3 className="text-xl font-semibold leading-5 text-gray-800">Note</h3>
      <div className="flex w-full space-y-4 flex-col border-gray-200 border-b pb-4">
        <p>{noteItem.note}</p>
      </div>
    </div>
  );
}

export default NoteComponent;
