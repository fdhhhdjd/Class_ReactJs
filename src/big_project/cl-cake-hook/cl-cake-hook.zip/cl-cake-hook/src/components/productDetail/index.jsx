import { useEffect, useReducer, useState } from 'react';
import { useParams } from 'react-router-dom';
import ImageProduct from './ImageProduct';

import { clearDetailProduct, getProductDetailSuccess } from '@/providers/reducer/products/action';
import productReducer, { initState } from '@/providers/reducer/products/reducer';
import { MINIMUM_QUANTITY } from '../../configs';
import { addToCartMutingQuantity } from '@/providers/reducer/carts/action';
import { useCart } from '@/contexts';

function ProductDetail() {
  const { id } = useParams();

  const [state, dispatch] = useReducer(productReducer, initState);

  const { dispatch: dispatchCart } = useCart();
  const { productDetail } = state;

  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    dispatch(getProductDetailSuccess({ id: +id }));
    return () => {
      dispatch(clearDetailProduct());
    };
  }, [id]);

  const addToCartHandler = async (id) => {
    dispatchCart(addToCartMutingQuantity({ productId: id, quantity }));
  };

  const increaseQuantity = () => {
    if (quantity < productDetail.stock_count) {
      setQuantity(quantity + 1);
    }
  };

  const decreaseQuantity = () => {
    if (quantity > MINIMUM_QUANTITY) {
      setQuantity(quantity - 1);
    }
  };

  return (
    <>
      {productDetail && (
        <div className="w-full lg:flex justify-between">
          <div className="lg:w-1/2 xl:mr-[70px] lg:mr-[50px]">
            <ImageProduct productDetail={productDetail} />
          </div>

          <div className="flex-1">
            <div className="w-full mt-10 lg:mt-0">
              <span className="text-gray text-xs font-normal uppercase tracking-wider mb-2 inline-block">
                {productDetail.name}
              </span>
              <p className="text-xl font-medium text-black mb-4">{productDetail.description}</p>

              <div className="flex space-x-[10px] items-center mb-6">
                <div className="flex">
                  <span>
                    <i className="fa-solid fa-star" style={{ color: '#ffa800' }}></i>
                  </span>
                  <span>
                    <i className="fa-solid fa-star" style={{ color: '#ffa800' }}></i>
                  </span>
                  <span>
                    <i className="fa-solid fa-star" style={{ color: '#ffa800' }}></i>
                  </span>
                </div>
                <span className="text-[13px] font-normal text-black-500">6 Reviews</span>
              </div>

              <div className="flex space-x-2 items-center mb-7">
                <span
                  className={
                    productDetail.discounted_price
                      ? 'text-sm font-500 text-gray-500 line-through mt-2'
                      : 'text-2xl font-500'
                  }
                >
                  ${productDetail.original_price}
                </span>

                {productDetail.discounted_price && <span>-</span>}

                <span
                  className={productDetail.discounted_price ? 'text-2xl font-500 text-red-500' : ''}
                >
                  ${productDetail.discounted_price}
                </span>
              </div>
              <div className="flex space-x-2 items-center mb-7">
                <span className="text-sm font-500 text-gray-500 mt-2">Stock:</span>
                <span className="text-2xl font-500">{productDetail.stock_count}</span>
              </div>

              <p className="text-gray-500 text-sm text-normal mb-[30px] leading-7">
                It is a long established fact that a reader will be distracted by the readable there
                content of a page when looking at its layout
              </p>

              <div className="w-full flex items-center h-[50px] space-x-[10px] mb-[30px]">
                <div className="w-[120px] h-full px-[26px] flex items-center border border-gray">
                  <div className="flex justify-between items-center w-full">
                    <button className="text-base text-gray-500" onClick={decreaseQuantity}>
                      -
                    </button>
                    <span> {quantity} </span>
                    <button className="text-base text-gray-500" onClick={increaseQuantity}>
                      +
                    </button>
                  </div>
                </div>

                <div className="h-full">
                  <button
                    className="bg-gray-900 px-16 text-white hover:opacity-75 text-sm font-semibold w-full h-full"
                    onClick={() => addToCartHandler(productDetail.id)}
                  >
                    Add To Cart
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default ProductDetail;
