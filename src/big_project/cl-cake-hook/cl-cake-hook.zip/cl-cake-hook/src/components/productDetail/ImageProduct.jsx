import { getImage } from '../../utils';

function ProductImage({ productDetail }) {
  return (
    <div className="w-full">
      <div className="w-full h-[600px] border border-gray-border flex justify-center items-center overflow-hidden relative mb-3">
        <img
          src={getImage(productDetail.image_url)}
          alt=""
          className="transition-all duration-200 hover:scale-110"
        />
      </div>
    </div>
  );
}

export default ProductImage;
