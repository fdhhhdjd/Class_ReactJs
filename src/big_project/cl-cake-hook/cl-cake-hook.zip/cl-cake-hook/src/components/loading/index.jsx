import React, { Fragment } from 'react';
import '@/styles/Loading.css';
const Loading = () => {
  return (
    <Fragment>
      <div id="app">
        <div class="loader"></div>
      </div>
    </Fragment>
  );
};

export default Loading;
