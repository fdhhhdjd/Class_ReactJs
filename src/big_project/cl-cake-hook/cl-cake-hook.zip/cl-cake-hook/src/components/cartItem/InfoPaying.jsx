import { useCart } from '@/contexts';
import { useState } from 'react';
import OrderConfirmation from '../../components/confirmation';
import { CHARACTER, VALIDATE } from '../../configs';

const CartCheckout = () => {
  const { state } = useCart();

  const [note, setNote] = useState('');
  const [message, setMessage] = useState(null);
  const [showConfirmation, setShowConfirmation] = useState(false);

  const showOrderConfirmation = () => {
    if (!message) {
      setShowConfirmation(true);
    }
  };

  const hideOrderConfirmation = () => {
    setShowConfirmation(false);
  };

  const handleInput = (event) => {
    const inputValue = event.target.value;
    setNote(inputValue);

    if (inputValue.length > CHARACTER._25) {
      setMessage(VALIDATE.NOTE);
    } else {
      setMessage(null);
    }
  };

  return (
    <div className="w-full mt-[23px]">
      <div className="container mx-auto">
        <div className="flex flex-wrap justify-between">
          <div className="w-full lg:w-1/2 sm:flex justify-between mb-10">
            <div className="lg:w-[570px] w-full mb-5 sm:mb-0 h-full flex">
              <div className="flex-1 h-full">
                <label
                  htmlFor="message"
                  className="block mb-2 text-lg font-medium text-gray-900 dark:text-white"
                >
                  Note
                </label>
                <textarea
                  id="message"
                  value={note}
                  rows="5"
                  className={`border p-2.5 placeholder:text-lg text-lg px-6 text-dark-gray w-full h-40 rounded-lg font-normal bg-white focus:outline-none ${
                    message ? 'border-2 border-red-500 animate-snake' : 'focus:border-yellow-500'
                  }`}
                  placeholder="Write your thoughts here..."
                  onChange={handleInput}
                ></textarea>
                {message && <span className="mt-30 text-red-500">{message}</span>}
              </div>
            </div>
          </div>
          <div className="mt-8 w-full lg:w-1/2 flex sm:justify-end">
            <div className="lg:w-[370px] w-full border border-[#ededed] px-[30px] py-[26px]">
              <div className="mb-6">
                <div className="flex justify-between mb-6">
                  <p className="text-[15px] font-medium text-black">Cost Total</p>
                  <p className="text-[15px] font-medium text-red-500">${state.cost}</p>
                </div>
                <div className="w-full h-[1px] bg-[#ededed]"></div>
              </div>
              <div className="w-full mb-3">
                <div className="mb-[17px]">
                  <h1 className="text-[15px] font-medium">Calculate Shipping</h1>
                </div>
                <div className="w-full h-[50px] border border-[#EDEDED] px-5 flex justify-between items-center mb-10">
                  <input
                    type="text"
                    placeholder="Enter Address..."
                    className="input-field placeholder:text-sm text-sm px-6 text-dark-gray w-full h-full font-normal bg-white focus:ring-0 focus:outline-none w-full h-full"
                  />
                </div>
                <div className="mb-6">
                  <div className="flex justify-between">
                    <p className="text-[18px] font-medium text-black">Total</p>
                    <p className="text-[18px] font-medium text-red-500">${state.total}</p>
                  </div>
                </div>
              </div>
              <div className="w-full h-[50px] bg-black text-white flex justify-center items-center">
                <button className="text-sm font-semibold" onClick={showOrderConfirmation}>
                  Proceed to Checkout
                </button>
                {showConfirmation && (
                  <OrderConfirmation
                    showConfirmation={showConfirmation}
                    hideOrderConfirmation={hideOrderConfirmation}
                    valueNote={note}
                    valueMessage={message}
                  />
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartCheckout;
