import { SUCCESS } from '@/configs';
import { useCart } from '@/contexts';
import {
  decrementCart,
  deleteAllCart,
  deleteToCart,
  incrementCart,
} from '@/providers/reducer/carts/action';
import { getImage, rouserNumber } from '@/utils';
import { showSuccessToast } from '@/utils/toast';
import { Link } from 'react-router-dom';

const Cart = () => {
  const { state, dispatch } = useCart();

  const handleDeleteCart = (id) => {
    dispatch(deleteToCart({ productId: id }));
  };

  const handleIncrementQuantity = (id) => {
    dispatch(incrementCart({ productId: id }));
  };

  const handleDecrementQuantity = (id) => {
    dispatch(decrementCart({ productId: id }));
  };

  const handleRemoveAllCart = () => {
    dispatch(deleteAllCart());

    showSuccessToast(SUCCESS.DELETE_ALL_CART);
  };

  return (
    <div className="relative w-full overflow-x-auto border border-[#ededed]">
      <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
        <tbody>
          <tr className="text-[13px] font-medium text-black bg-[#f6f6f6] whitespace-nowrap px-2 border-b default-border-bottom uppercase">
            <td className="py-4 pl-10 whitespace-nowrap min-w-[300px]">Product</td>
            <td className="py-4 whitespace-nowrap min-w-[200px] text-center">Price</td>
            <td className="py-4 whitespace-nowrap min-w-[200px] text-center">Discounted price</td>
            <td className="py-4 whitespace-nowrap min-w-[300px] text-center">Quantity</td>
            <td className="py-4 whitespace-nowrap min-w-[300px] text-center">Total</td>
            <td className="py-4 pr-5 whitespace-nowrap text-center w-[200px]">
              <button
                className="flex items-center justify-center font-semibold text-red-500 w-full text-sm"
                onClick={handleRemoveAllCart}
              >
                <span className="fill-current mr-2 text w-4 text-red-500">
                  <i className="fa-solid fa-trash"></i>
                </span>
                Remove all
              </button>
            </td>
          </tr>

          {/* Data */}
          {state.cart.map((cart) => (
            <tr key={cart.id} className="bg-white border-b hover:bg-gray-50">
              <td className="pl-10 py-4 w-[380px]">
                <div className="flex space-x-6 items-center">
                  <div className="w-[80px] h-[80px] overflow-hidden flex justify-center items-center border border-[#ededed] relative">
                    <img
                      src={getImage(cart.image_url)}
                      alt="product"
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <div className="flex-1 flex flex-col">
                    <Link to={`/product/${cart.id}`}>
                      <p className="font-medium text-[15px] text-black-500">{cart.name}</p>
                    </Link>
                  </div>
                </div>
              </td>

              <td className="text-center py-4 px-2">
                <div className="flex space-x-1 items-center justify-center">
                  <span
                    className={
                      cart.discounted_price
                        ? 'line-through text-[15px] font-normal'
                        : 'text-[15px] font-normal'
                    }
                  >
                    $ {cart.original_price}
                  </span>
                </div>
              </td>

              <td className="text-center py-4 px-2">
                <div className="flex space-x-1 items-center justify-center">
                  <span
                    className={
                      cart.discounted_price
                        ? 'text-red-500 text-[15px] font-normal'
                        : 'text-[15px] font-normal'
                    }
                  >
                    $ {cart.discounted_price || cart.original_price}
                  </span>
                </div>
              </td>

              <td className="text-center py-4 px-2">
                <div className="flex justify-center items-center">
                  <div className="w-[120px] h-[40px] px-[26px] flex items-center border border-gray-300">
                    <div className="flex justify-between items-center w-full">
                      <button
                        className="text-base text-gray-500"
                        onClick={() => handleDecrementQuantity(cart.id)}
                      >
                        -
                      </button>
                      <span>{cart.quantity}</span>
                      <button
                        className="text-base text-gray-500"
                        onClick={() => handleIncrementQuantity(cart.id)}
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              </td>

              <td className="text-right py-4 px-2">
                <div className="flex space-x-1 items-center justify-center">
                  <span className="text-[15px] font-normal">
                    ${rouserNumber((cart.discounted_price || cart.original_price) * cart.quantity)}
                  </span>
                </div>
              </td>

              <td className="text-right py-4">
                <div
                  className="flex space-x-1 items-center justify-cestoreCartnter"
                  onClick={() => handleDeleteCart(cart.id)}
                >
                  <span className="cursor-pointer flex p-4 rounded-full items-center justify-center hover:bg-gray-200">
                    <i className="fa-solid fa-xmark"></i>
                  </span>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Cart;
